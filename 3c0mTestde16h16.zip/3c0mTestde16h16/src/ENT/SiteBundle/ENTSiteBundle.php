<?php

namespace ENT\SiteBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ENTSiteBundle extends Bundle
{
}
