<?php
namespace ENT\SiteBundle\Controller;

use ENT\SiteBundle\Entity\Logiciels;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

class LogicielsController extends Controller
{
    public function view2Action($idCat)
    {
        var_dump($idCat);
     // On récupère le repository
     $repository = $this->getDoctrine()
       ->getManager()
       ->getRepository('ENTSiteBundle:Logiciels');
       //var_dump($repository);
     // On récupère l'entité correspondante à l'id $id
     $logiciels = $repository->findBy(
    array('idCat' => $idCat)

);
var_dump($logiciels);
  //   var_dump($documentation);
     //var_dump($documentation);
     $error = "TEST DONE !";

     //var_dump($doc);
     // $advert est donc une instance de OC\PlatformBundle\Entity\Advert
     // ou null si l'id $id  n'existe pas, d'où ce if :
     if (null === $logiciels) {
         $error = "L'annonce d'id ".$idCat." n'existe pas.";
     } else {

        $cont = array();
        $log = new Logiciels();
        foreach ($logiciels as $log){
        $nom = $log->getNom();
        $taille = $log->getTaille();
        array_push($cont, $nom, $taille);


    // $date_enrg = $documentation->getDataEnregistrement();
 }
 $content = $this
     ->render('ENTSiteBundle:Membre:logi.html.twig', array('log' => $cont));
//var_dump($content);
     // Le render ne change pas, on passait avant un tableau, maintenant un objet
return new Response($content);
    }
}
}
