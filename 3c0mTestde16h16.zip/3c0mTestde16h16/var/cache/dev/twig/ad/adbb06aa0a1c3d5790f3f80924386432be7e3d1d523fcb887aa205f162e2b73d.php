<?php

/* ENTSiteBundle:Membre:support.html.twig */
class __TwigTemplate_95f2e5b4c307f24ddac355154b9fe4502e518129fdf14f119942b8fdf04adf11 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.menu.html.twig", "ENTSiteBundle:Membre:support.html.twig", 1);
        $this->blocks = array(
            'login' => array($this, 'block_login'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.menu.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_89ff0742a65a74bde461b6e8e81e5b8728fab16697f2f495523f1b5989ed1513 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_89ff0742a65a74bde461b6e8e81e5b8728fab16697f2f495523f1b5989ed1513->enter($__internal_89ff0742a65a74bde461b6e8e81e5b8728fab16697f2f495523f1b5989ed1513_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "ENTSiteBundle:Membre:support.html.twig"));

        $__internal_6c9d1d22b8afba9978cbd18b1067769a3e59f74375aa0cab5f99add652caa5cb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6c9d1d22b8afba9978cbd18b1067769a3e59f74375aa0cab5f99add652caa5cb->enter($__internal_6c9d1d22b8afba9978cbd18b1067769a3e59f74375aa0cab5f99add652caa5cb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "ENTSiteBundle:Membre:support.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_89ff0742a65a74bde461b6e8e81e5b8728fab16697f2f495523f1b5989ed1513->leave($__internal_89ff0742a65a74bde461b6e8e81e5b8728fab16697f2f495523f1b5989ed1513_prof);

        
        $__internal_6c9d1d22b8afba9978cbd18b1067769a3e59f74375aa0cab5f99add652caa5cb->leave($__internal_6c9d1d22b8afba9978cbd18b1067769a3e59f74375aa0cab5f99add652caa5cb_prof);

    }

    // line 2
    public function block_login($context, array $blocks = array())
    {
        $__internal_6133dbe4fd2c6cccd416e1c59bf36c6d64ef2334f8af0432d8f7231621a7d11d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6133dbe4fd2c6cccd416e1c59bf36c6d64ef2334f8af0432d8f7231621a7d11d->enter($__internal_6133dbe4fd2c6cccd416e1c59bf36c6d64ef2334f8af0432d8f7231621a7d11d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "login"));

        $__internal_91c31237974178b2f0d1e1d237ede6baef808c596d75042bebbf855c9456cf36 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_91c31237974178b2f0d1e1d237ede6baef808c596d75042bebbf855c9456cf36->enter($__internal_91c31237974178b2f0d1e1d237ede6baef808c596d75042bebbf855c9456cf36_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "login"));

        // line 3
        echo "
  <li class=\"active\">
    <a class=\"ww\" href=\"";
        // line 5
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("lo_gin");
        echo "\">Déconnexion</a>
  </li>

";
        
        $__internal_91c31237974178b2f0d1e1d237ede6baef808c596d75042bebbf855c9456cf36->leave($__internal_91c31237974178b2f0d1e1d237ede6baef808c596d75042bebbf855c9456cf36_prof);

        
        $__internal_6133dbe4fd2c6cccd416e1c59bf36c6d64ef2334f8af0432d8f7231621a7d11d->leave($__internal_6133dbe4fd2c6cccd416e1c59bf36c6d64ef2334f8af0432d8f7231621a7d11d_prof);

    }

    // line 9
    public function block_body($context, array $blocks = array())
    {
        $__internal_15f0119399b119a346fa0aef82efa04036f2eabf95503ed7f3d0ab47e3dc9c84 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_15f0119399b119a346fa0aef82efa04036f2eabf95503ed7f3d0ab47e3dc9c84->enter($__internal_15f0119399b119a346fa0aef82efa04036f2eabf95503ed7f3d0ab47e3dc9c84_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_885d79bf4a5a8501ac36257f03efba7d3c0fd353f30cbe1b63ffefd89ea42b87 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_885d79bf4a5a8501ac36257f03efba7d3c0fd353f30cbe1b63ffefd89ea42b87->enter($__internal_885d79bf4a5a8501ac36257f03efba7d3c0fd353f30cbe1b63ffefd89ea42b87_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 10
        echo "  support
  <div id=\"test\">
    <h1>
      ";
        // line 13
        echo twig_escape_filter($this->env, twig_upper_filter($this->env, (isset($context["test"]) ? $context["test"] : $this->getContext($context, "test"))), "html", null, true);
        echo "
    </h1>
  </div>
";
        
        $__internal_885d79bf4a5a8501ac36257f03efba7d3c0fd353f30cbe1b63ffefd89ea42b87->leave($__internal_885d79bf4a5a8501ac36257f03efba7d3c0fd353f30cbe1b63ffefd89ea42b87_prof);

        
        $__internal_15f0119399b119a346fa0aef82efa04036f2eabf95503ed7f3d0ab47e3dc9c84->leave($__internal_15f0119399b119a346fa0aef82efa04036f2eabf95503ed7f3d0ab47e3dc9c84_prof);

    }

    public function getTemplateName()
    {
        return "ENTSiteBundle:Membre:support.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  82 => 13,  77 => 10,  68 => 9,  54 => 5,  50 => 3,  41 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.menu.html.twig' %}
{% block login %}

  <li class=\"active\">
    <a class=\"ww\" href=\"{{ path('lo_gin') }}\">Déconnexion</a>
  </li>

{% endblock %}
{% block body %}
  support
  <div id=\"test\">
    <h1>
      {{ test|upper }}
    </h1>
  </div>
{% endblock %}
", "ENTSiteBundle:Membre:support.html.twig", "/opt/lampp/htdocs/3c0m/src/ENT/SiteBundle/Resources/views/Membre/support.html.twig");
    }
}
