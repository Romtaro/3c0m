<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_a0ab1fb4a0aa09ee5535a80573bc6497da13d5b38022c26061960146fcaea2bd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_575e358388399f3ae14fcb76f2b8381bed7fb542944e4138e849146be562ce36 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_575e358388399f3ae14fcb76f2b8381bed7fb542944e4138e849146be562ce36->enter($__internal_575e358388399f3ae14fcb76f2b8381bed7fb542944e4138e849146be562ce36_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $__internal_f95d130cd4c301b6141555b7d2311026c40e36be60a0b8ea3394370e79629574 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f95d130cd4c301b6141555b7d2311026c40e36be60a0b8ea3394370e79629574->enter($__internal_f95d130cd4c301b6141555b7d2311026c40e36be60a0b8ea3394370e79629574_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_575e358388399f3ae14fcb76f2b8381bed7fb542944e4138e849146be562ce36->leave($__internal_575e358388399f3ae14fcb76f2b8381bed7fb542944e4138e849146be562ce36_prof);

        
        $__internal_f95d130cd4c301b6141555b7d2311026c40e36be60a0b8ea3394370e79629574->leave($__internal_f95d130cd4c301b6141555b7d2311026c40e36be60a0b8ea3394370e79629574_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_2492188836214ec04b7819d32e2d725f632d55e276d0c6ad84a1c3b240d40839 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2492188836214ec04b7819d32e2d725f632d55e276d0c6ad84a1c3b240d40839->enter($__internal_2492188836214ec04b7819d32e2d725f632d55e276d0c6ad84a1c3b240d40839_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_69380cb7150db7dbdf9aa636c3676cfed5ef513d289c4098afa95cab3d86b075 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_69380cb7150db7dbdf9aa636c3676cfed5ef513d289c4098afa95cab3d86b075->enter($__internal_69380cb7150db7dbdf9aa636c3676cfed5ef513d289c4098afa95cab3d86b075_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_69380cb7150db7dbdf9aa636c3676cfed5ef513d289c4098afa95cab3d86b075->leave($__internal_69380cb7150db7dbdf9aa636c3676cfed5ef513d289c4098afa95cab3d86b075_prof);

        
        $__internal_2492188836214ec04b7819d32e2d725f632d55e276d0c6ad84a1c3b240d40839->leave($__internal_2492188836214ec04b7819d32e2d725f632d55e276d0c6ad84a1c3b240d40839_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_3610e71e6667365bb1cc1ffbe891e2b5d10fad8ba88d58117998de6177549da8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3610e71e6667365bb1cc1ffbe891e2b5d10fad8ba88d58117998de6177549da8->enter($__internal_3610e71e6667365bb1cc1ffbe891e2b5d10fad8ba88d58117998de6177549da8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_a316bcb352e9154a4712e037eb09bdeb6a49c9bbff31394ec4273dabdb5df73b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a316bcb352e9154a4712e037eb09bdeb6a49c9bbff31394ec4273dabdb5df73b->enter($__internal_a316bcb352e9154a4712e037eb09bdeb6a49c9bbff31394ec4273dabdb5df73b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_a316bcb352e9154a4712e037eb09bdeb6a49c9bbff31394ec4273dabdb5df73b->leave($__internal_a316bcb352e9154a4712e037eb09bdeb6a49c9bbff31394ec4273dabdb5df73b_prof);

        
        $__internal_3610e71e6667365bb1cc1ffbe891e2b5d10fad8ba88d58117998de6177549da8->leave($__internal_3610e71e6667365bb1cc1ffbe891e2b5d10fad8ba88d58117998de6177549da8_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_2ba1efd4896dd9172970fac99235ca4841fbb2cdf8a5acf2a65eb98a1b810780 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2ba1efd4896dd9172970fac99235ca4841fbb2cdf8a5acf2a65eb98a1b810780->enter($__internal_2ba1efd4896dd9172970fac99235ca4841fbb2cdf8a5acf2a65eb98a1b810780_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_4c70818324a641e6750f79d8b46ea22553902ff5b897626458e807d9f30231ac = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4c70818324a641e6750f79d8b46ea22553902ff5b897626458e807d9f30231ac->enter($__internal_4c70818324a641e6750f79d8b46ea22553902ff5b897626458e807d9f30231ac_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_4c70818324a641e6750f79d8b46ea22553902ff5b897626458e807d9f30231ac->leave($__internal_4c70818324a641e6750f79d8b46ea22553902ff5b897626458e807d9f30231ac_prof);

        
        $__internal_2ba1efd4896dd9172970fac99235ca4841fbb2cdf8a5acf2a65eb98a1b810780->leave($__internal_2ba1efd4896dd9172970fac99235ca4841fbb2cdf8a5acf2a65eb98a1b810780_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "/opt/lampp/htdocs/3c0m/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Collector/router.html.twig");
    }
}
