<?php

/* ENTSiteBundle:Membre:ressources_error.html.twig */
class __TwigTemplate_882388088636e8577df940a44633d1d34e863c4c1a921aee5b93a092c0ee97c7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.menu.html.twig", "ENTSiteBundle:Membre:ressources_error.html.twig", 1);
        $this->blocks = array(
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
            'login' => array($this, 'block_login'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.menu.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d7caa98809d0367b693a1652c2ee47f02cadbde7bb00e23f2807575dc66b4be1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d7caa98809d0367b693a1652c2ee47f02cadbde7bb00e23f2807575dc66b4be1->enter($__internal_d7caa98809d0367b693a1652c2ee47f02cadbde7bb00e23f2807575dc66b4be1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "ENTSiteBundle:Membre:ressources_error.html.twig"));

        $__internal_2acc0d8ae9173d85da1b798968dea41a3cde94dc067a1006663444d9d38750aa = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2acc0d8ae9173d85da1b798968dea41a3cde94dc067a1006663444d9d38750aa->enter($__internal_2acc0d8ae9173d85da1b798968dea41a3cde94dc067a1006663444d9d38750aa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "ENTSiteBundle:Membre:ressources_error.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_d7caa98809d0367b693a1652c2ee47f02cadbde7bb00e23f2807575dc66b4be1->leave($__internal_d7caa98809d0367b693a1652c2ee47f02cadbde7bb00e23f2807575dc66b4be1_prof);

        
        $__internal_2acc0d8ae9173d85da1b798968dea41a3cde94dc067a1006663444d9d38750aa->leave($__internal_2acc0d8ae9173d85da1b798968dea41a3cde94dc067a1006663444d9d38750aa_prof);

    }

    // line 3
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_0dd7ab4423036e9a69b02216bc1153fe5ed57db17dc06ba412a97a838d49fac3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0dd7ab4423036e9a69b02216bc1153fe5ed57db17dc06ba412a97a838d49fac3->enter($__internal_0dd7ab4423036e9a69b02216bc1153fe5ed57db17dc06ba412a97a838d49fac3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_908980ddedab9df7881987ef50b97d337f03b7661dd54fa78fbc61d0580d217a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_908980ddedab9df7881987ef50b97d337f03b7661dd54fa78fbc61d0580d217a->enter($__internal_908980ddedab9df7881987ef50b97d337f03b7661dd54fa78fbc61d0580d217a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 4
        echo "  <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/dropzone.css"), "html", null, true);
        echo "\">
  <link rel=\"stylesheet\" href=\"";
        // line 5
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/styles.css"), "html", null, true);
        echo "\">
";
        
        $__internal_908980ddedab9df7881987ef50b97d337f03b7661dd54fa78fbc61d0580d217a->leave($__internal_908980ddedab9df7881987ef50b97d337f03b7661dd54fa78fbc61d0580d217a_prof);

        
        $__internal_0dd7ab4423036e9a69b02216bc1153fe5ed57db17dc06ba412a97a838d49fac3->leave($__internal_0dd7ab4423036e9a69b02216bc1153fe5ed57db17dc06ba412a97a838d49fac3_prof);

    }

    // line 8
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_7340f40cde2749d9b4069e01a8c37b2b70076440fabca73df2cebae1b06bf1a4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7340f40cde2749d9b4069e01a8c37b2b70076440fabca73df2cebae1b06bf1a4->enter($__internal_7340f40cde2749d9b4069e01a8c37b2b70076440fabca73df2cebae1b06bf1a4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_d1542439c65cc67cb89611289198f14fa88e4a49b8b35a38616dd6c647c2fbb0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d1542439c65cc67cb89611289198f14fa88e4a49b8b35a38616dd6c647c2fbb0->enter($__internal_d1542439c65cc67cb89611289198f14fa88e4a49b8b35a38616dd6c647c2fbb0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 9
        echo "  <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js\"></script>

";
        
        $__internal_d1542439c65cc67cb89611289198f14fa88e4a49b8b35a38616dd6c647c2fbb0->leave($__internal_d1542439c65cc67cb89611289198f14fa88e4a49b8b35a38616dd6c647c2fbb0_prof);

        
        $__internal_7340f40cde2749d9b4069e01a8c37b2b70076440fabca73df2cebae1b06bf1a4->leave($__internal_7340f40cde2749d9b4069e01a8c37b2b70076440fabca73df2cebae1b06bf1a4_prof);

    }

    // line 12
    public function block_login($context, array $blocks = array())
    {
        $__internal_a72e081e43061e65a86040a211bbe935c673c674a79a31aa5c30d4cf8f20260f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a72e081e43061e65a86040a211bbe935c673c674a79a31aa5c30d4cf8f20260f->enter($__internal_a72e081e43061e65a86040a211bbe935c673c674a79a31aa5c30d4cf8f20260f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "login"));

        $__internal_d56fa446ec89543560f2d489754e1bdce27fc11cb4e06f756d7985c0d11f71e1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d56fa446ec89543560f2d489754e1bdce27fc11cb4e06f756d7985c0d11f71e1->enter($__internal_d56fa446ec89543560f2d489754e1bdce27fc11cb4e06f756d7985c0d11f71e1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "login"));

        // line 13
        echo "
  <li class=\"active\">
    <a class=\"ww\" href=\"";
        // line 15
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("lo_gin");
        echo "\">Déconnexion</a>
  </li>

";
        
        $__internal_d56fa446ec89543560f2d489754e1bdce27fc11cb4e06f756d7985c0d11f71e1->leave($__internal_d56fa446ec89543560f2d489754e1bdce27fc11cb4e06f756d7985c0d11f71e1_prof);

        
        $__internal_a72e081e43061e65a86040a211bbe935c673c674a79a31aa5c30d4cf8f20260f->leave($__internal_a72e081e43061e65a86040a211bbe935c673c674a79a31aa5c30d4cf8f20260f_prof);

    }

    // line 19
    public function block_body($context, array $blocks = array())
    {
        $__internal_f9e71d7967047fb71738ababbf2945ea06486ff63e42be8bbc0b1d5481f9204f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f9e71d7967047fb71738ababbf2945ea06486ff63e42be8bbc0b1d5481f9204f->enter($__internal_f9e71d7967047fb71738ababbf2945ea06486ff63e42be8bbc0b1d5481f9204f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_a985ca22a4ff6fb0af8d67a382bdd14cf128a3dd3d3968e8918fbd9b898830fa = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a985ca22a4ff6fb0af8d67a382bdd14cf128a3dd3d3968e8918fbd9b898830fa->enter($__internal_a985ca22a4ff6fb0af8d67a382bdd14cf128a3dd3d3968e8918fbd9b898830fa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 20
        echo "  <div id=\"bg\">
    <div id=\"test\">
      <h1>
        ";
        // line 23
        echo twig_escape_filter($this->env, (isset($context["test"]) ? $context["test"] : $this->getContext($context, "test")), "html", null, true);
        echo "
      </h1>
    </div>
    ";
        // line 29
        echo "
    <div id=\"\" style=\"\">
      <ul >
      <li>
        <a style=\"color:white;text-decoration:none;\" href=\"";
        // line 33
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("re_ssources_id_1");
        echo "\">
          <i class=\"fa fa-fw fa-lg fa-tachometer\"></i>
          res/{id} where {id}=1 | Correspond à : SELECT * FROM documentation WHERE id_documentation=1 sans SQL (les bundles natifs s'en charge)
        </a>
      </li>
    </ul>
  </div>

</div>
</div>
";
        
        $__internal_a985ca22a4ff6fb0af8d67a382bdd14cf128a3dd3d3968e8918fbd9b898830fa->leave($__internal_a985ca22a4ff6fb0af8d67a382bdd14cf128a3dd3d3968e8918fbd9b898830fa_prof);

        
        $__internal_f9e71d7967047fb71738ababbf2945ea06486ff63e42be8bbc0b1d5481f9204f->leave($__internal_f9e71d7967047fb71738ababbf2945ea06486ff63e42be8bbc0b1d5481f9204f_prof);

    }

    public function getTemplateName()
    {
        return "ENTSiteBundle:Membre:ressources_error.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  143 => 33,  137 => 29,  131 => 23,  126 => 20,  117 => 19,  103 => 15,  99 => 13,  90 => 12,  78 => 9,  69 => 8,  57 => 5,  52 => 4,  43 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.menu.html.twig' %}

{% block stylesheets %}
  <link rel=\"stylesheet\" href=\"{{ asset('css/dropzone.css') }}\">
  <link rel=\"stylesheet\" href=\"{{ asset('css/styles.css') }}\">
{% endblock %}

{% block javascripts %}
  <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js\"></script>

{% endblock %}
{% block login %}

  <li class=\"active\">
    <a class=\"ww\" href=\"{{ path('lo_gin') }}\">Déconnexion</a>
  </li>

{% endblock %}
{% block body %}
  <div id=\"bg\">
    <div id=\"test\">
      <h1>
        {{ test }}
      </h1>
    </div>
    {# {{ path('ajax_snippet_image_send') }}
    <div class=\"dropzone my-dropzone\" id=\"form_snippet_image\" action=\"\">
          <script type=\"text/javascript\" src=\"{{ asset('js/dropzone.js') }}\"></script> #}

    <div id=\"\" style=\"\">
      <ul >
      <li>
        <a style=\"color:white;text-decoration:none;\" href=\"{{ path('re_ssources_id_1') }}\">
          <i class=\"fa fa-fw fa-lg fa-tachometer\"></i>
          res/{id} where {id}=1 | Correspond à : SELECT * FROM documentation WHERE id_documentation=1 sans SQL (les bundles natifs s'en charge)
        </a>
      </li>
    </ul>
  </div>

</div>
</div>
{% endblock %}
", "ENTSiteBundle:Membre:ressources_error.html.twig", "/opt/lampp/htdocs/3c0m/src/ENT/SiteBundle/Resources/views/Membre/ressources_error.html.twig");
    }
}
