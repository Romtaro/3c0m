<?php

/* base.menu.html.twig */
class __TwigTemplate_fbc4cf97ff9d0971796e0bbb26be4e11e1b05bb54531396b2ab02ab7d38507c3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
            'login' => array($this, 'block_login'),
            'body' => array($this, 'block_body'),
            'log' => array($this, 'block_log'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e5de324ef6b61daa2bc21e37f8e0ed7365f123798a914dfb9f03391d83161b05 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e5de324ef6b61daa2bc21e37f8e0ed7365f123798a914dfb9f03391d83161b05->enter($__internal_e5de324ef6b61daa2bc21e37f8e0ed7365f123798a914dfb9f03391d83161b05_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.menu.html.twig"));

        $__internal_7bb303024ab37759f7e567ab068d7b8e8b6de81115637385343e9d328c9ca37b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7bb303024ab37759f7e567ab068d7b8e8b6de81115637385343e9d328c9ca37b->enter($__internal_7bb303024ab37759f7e567ab068d7b8e8b6de81115637385343e9d328c9ca37b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.menu.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
  <head>
    <meta charset=\"UTF-8\"/>

    <title>
      ";
        // line 7
        $this->displayBlock('title', $context, $blocks);
        // line 10
        echo "    </title>
    <link rel=\"stylesheet\" href=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("font-awesome/css/font-awesome.min.css"), "html", null, true);
        echo "\">
    <link rel=\"stylesheet\" href=\"";
        // line 12
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/menu_left_panel.css"), "html", null, true);
        echo "\">
    ";
        // line 13
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 14
        echo "    ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 15
        echo "    <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("icon.ico"), "html", null, true);
        echo "\"/>
  </head>
  <body>
    <style type=\"text/css\"></style>
    <div id=\"cssmenu\">
      <ul>
        <li>
          <a href=\"";
        // line 22
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("panel_membre");
        echo "\">
            <i class=\"fa fa-fw fa-3x fa-tachometer\"></i><br/>
            Tableau de Bord</a>
        </li>
        <li class=\"has-sub\">
          <a href=\"";
        // line 27
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("re_ssources");
        echo "\">
            <i class=\"fa fa-fw fa-3x fa-folder-open-o\"></i><br/>
            Ressources</a>
          <!--<ul>
            <li class=\"has-sub\">
              <a href=\"#\">Menu 1</a>
               <ul>
                <li>
                  <a href=\"#\">Menu 1.1</a>
                </li>
                <li>
                  <a href=\"#\">Menu 1.2</a>
                </li>
              </ul>
            </li>
            <li>
              <a href=\"#\">Menu 2</a>
            </li>
      </ul>-->
        </li>
        <li>
          <a href=\"";
        // line 48
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("su_pport");
        echo "\">
            <i class=\"fa fa-cog fa-spin fa-3x fa-fw\"></i><br/>
            <span class=\"sr-only\">Loading...</span>
            ";
        // line 52
        echo "            Support</a>
        </li>
        <li>
          <a href=\"";
        // line 55
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("f_aq");
        echo "\">
            <i class=\"fa fa-fw fa-3x fa-phone\"></i><br/>
            FAQ</a>
        </li>
        ";
        // line 59
        $this->displayBlock('login', $context, $blocks);
        // line 60
        echo "      </ul>
    </div>

    <div id=\"view_right\">

      ";
        // line 65
        $this->displayBlock('body', $context, $blocks);
        // line 66
        echo "      ";
        $this->displayBlock('log', $context, $blocks);
        // line 67
        echo "    </div>

  </body>
</html>
";
        
        $__internal_e5de324ef6b61daa2bc21e37f8e0ed7365f123798a914dfb9f03391d83161b05->leave($__internal_e5de324ef6b61daa2bc21e37f8e0ed7365f123798a914dfb9f03391d83161b05_prof);

        
        $__internal_7bb303024ab37759f7e567ab068d7b8e8b6de81115637385343e9d328c9ca37b->leave($__internal_7bb303024ab37759f7e567ab068d7b8e8b6de81115637385343e9d328c9ca37b_prof);

    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        $__internal_83b4101176f5a738ba6045b3a8aff416163e5426b965e65e408bfd5eb9053c62 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_83b4101176f5a738ba6045b3a8aff416163e5426b965e65e408bfd5eb9053c62->enter($__internal_83b4101176f5a738ba6045b3a8aff416163e5426b965e65e408bfd5eb9053c62_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_5deeb790f71f7ce4136362338a057313ba28c59a5710a990ebc6688c3f2d230c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5deeb790f71f7ce4136362338a057313ba28c59a5710a990ebc6688c3f2d230c->enter($__internal_5deeb790f71f7ce4136362338a057313ba28c59a5710a990ebc6688c3f2d230c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 8
        echo "        3c0m - SAV
      ";
        
        $__internal_5deeb790f71f7ce4136362338a057313ba28c59a5710a990ebc6688c3f2d230c->leave($__internal_5deeb790f71f7ce4136362338a057313ba28c59a5710a990ebc6688c3f2d230c_prof);

        
        $__internal_83b4101176f5a738ba6045b3a8aff416163e5426b965e65e408bfd5eb9053c62->leave($__internal_83b4101176f5a738ba6045b3a8aff416163e5426b965e65e408bfd5eb9053c62_prof);

    }

    // line 13
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_923e8f8797b403f1a7b723cea6a7712fcbe9a2ff1232b41c516261e2c49ae593 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_923e8f8797b403f1a7b723cea6a7712fcbe9a2ff1232b41c516261e2c49ae593->enter($__internal_923e8f8797b403f1a7b723cea6a7712fcbe9a2ff1232b41c516261e2c49ae593_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_8fc53b31950890d50071fc1b7468388e9bc9bceb8ce96f124cb410719a196546 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8fc53b31950890d50071fc1b7468388e9bc9bceb8ce96f124cb410719a196546->enter($__internal_8fc53b31950890d50071fc1b7468388e9bc9bceb8ce96f124cb410719a196546_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_8fc53b31950890d50071fc1b7468388e9bc9bceb8ce96f124cb410719a196546->leave($__internal_8fc53b31950890d50071fc1b7468388e9bc9bceb8ce96f124cb410719a196546_prof);

        
        $__internal_923e8f8797b403f1a7b723cea6a7712fcbe9a2ff1232b41c516261e2c49ae593->leave($__internal_923e8f8797b403f1a7b723cea6a7712fcbe9a2ff1232b41c516261e2c49ae593_prof);

    }

    // line 14
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_3969838e42cfb75cf203d45aac9dcd57686ca9147ccc858880cb22bb88b6dc28 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3969838e42cfb75cf203d45aac9dcd57686ca9147ccc858880cb22bb88b6dc28->enter($__internal_3969838e42cfb75cf203d45aac9dcd57686ca9147ccc858880cb22bb88b6dc28_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_e815319e1866d9e798055d34a18d44a3c9601ab3d5352aea199f0ff84d1417fc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e815319e1866d9e798055d34a18d44a3c9601ab3d5352aea199f0ff84d1417fc->enter($__internal_e815319e1866d9e798055d34a18d44a3c9601ab3d5352aea199f0ff84d1417fc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_e815319e1866d9e798055d34a18d44a3c9601ab3d5352aea199f0ff84d1417fc->leave($__internal_e815319e1866d9e798055d34a18d44a3c9601ab3d5352aea199f0ff84d1417fc_prof);

        
        $__internal_3969838e42cfb75cf203d45aac9dcd57686ca9147ccc858880cb22bb88b6dc28->leave($__internal_3969838e42cfb75cf203d45aac9dcd57686ca9147ccc858880cb22bb88b6dc28_prof);

    }

    // line 59
    public function block_login($context, array $blocks = array())
    {
        $__internal_d3e4e57638830b2d9351f020744e308113248c53218a7c4f1ca4ec570fab3ef7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d3e4e57638830b2d9351f020744e308113248c53218a7c4f1ca4ec570fab3ef7->enter($__internal_d3e4e57638830b2d9351f020744e308113248c53218a7c4f1ca4ec570fab3ef7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "login"));

        $__internal_6e0cce2f48a69e9fadb76cd17538751dc2b19b6394a1c89d3bd6ec0e98016afe = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6e0cce2f48a69e9fadb76cd17538751dc2b19b6394a1c89d3bd6ec0e98016afe->enter($__internal_6e0cce2f48a69e9fadb76cd17538751dc2b19b6394a1c89d3bd6ec0e98016afe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "login"));

        
        $__internal_6e0cce2f48a69e9fadb76cd17538751dc2b19b6394a1c89d3bd6ec0e98016afe->leave($__internal_6e0cce2f48a69e9fadb76cd17538751dc2b19b6394a1c89d3bd6ec0e98016afe_prof);

        
        $__internal_d3e4e57638830b2d9351f020744e308113248c53218a7c4f1ca4ec570fab3ef7->leave($__internal_d3e4e57638830b2d9351f020744e308113248c53218a7c4f1ca4ec570fab3ef7_prof);

    }

    // line 65
    public function block_body($context, array $blocks = array())
    {
        $__internal_79099c44d9065fdd517c932e490a22a57022c02b8a50b64e3b899bf2bfa81066 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_79099c44d9065fdd517c932e490a22a57022c02b8a50b64e3b899bf2bfa81066->enter($__internal_79099c44d9065fdd517c932e490a22a57022c02b8a50b64e3b899bf2bfa81066_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_73643dc536efbfecee175a919fa9d4d115d340a7acfe64818341ace1fdc4e37e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_73643dc536efbfecee175a919fa9d4d115d340a7acfe64818341ace1fdc4e37e->enter($__internal_73643dc536efbfecee175a919fa9d4d115d340a7acfe64818341ace1fdc4e37e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_73643dc536efbfecee175a919fa9d4d115d340a7acfe64818341ace1fdc4e37e->leave($__internal_73643dc536efbfecee175a919fa9d4d115d340a7acfe64818341ace1fdc4e37e_prof);

        
        $__internal_79099c44d9065fdd517c932e490a22a57022c02b8a50b64e3b899bf2bfa81066->leave($__internal_79099c44d9065fdd517c932e490a22a57022c02b8a50b64e3b899bf2bfa81066_prof);

    }

    // line 66
    public function block_log($context, array $blocks = array())
    {
        $__internal_d9133f4ab3052e59080a1ea8a8d440230eae117cb279f0c01fbe30a4eec0d698 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d9133f4ab3052e59080a1ea8a8d440230eae117cb279f0c01fbe30a4eec0d698->enter($__internal_d9133f4ab3052e59080a1ea8a8d440230eae117cb279f0c01fbe30a4eec0d698_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "log"));

        $__internal_c5cefff06d6b1cb0f1cad577ba1d5f8d6ed23e12c4057b0f43c48f7f962241ae = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c5cefff06d6b1cb0f1cad577ba1d5f8d6ed23e12c4057b0f43c48f7f962241ae->enter($__internal_c5cefff06d6b1cb0f1cad577ba1d5f8d6ed23e12c4057b0f43c48f7f962241ae_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "log"));

        
        $__internal_c5cefff06d6b1cb0f1cad577ba1d5f8d6ed23e12c4057b0f43c48f7f962241ae->leave($__internal_c5cefff06d6b1cb0f1cad577ba1d5f8d6ed23e12c4057b0f43c48f7f962241ae_prof);

        
        $__internal_d9133f4ab3052e59080a1ea8a8d440230eae117cb279f0c01fbe30a4eec0d698->leave($__internal_d9133f4ab3052e59080a1ea8a8d440230eae117cb279f0c01fbe30a4eec0d698_prof);

    }

    public function getTemplateName()
    {
        return "base.menu.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  234 => 66,  217 => 65,  200 => 59,  183 => 14,  166 => 13,  155 => 8,  146 => 7,  132 => 67,  129 => 66,  127 => 65,  120 => 60,  118 => 59,  111 => 55,  106 => 52,  100 => 48,  76 => 27,  68 => 22,  57 => 15,  54 => 14,  52 => 13,  48 => 12,  44 => 11,  41 => 10,  39 => 7,  31 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
  <head>
    <meta charset=\"UTF-8\"/>

    <title>
      {% block title %}
        3c0m - SAV
      {% endblock %}
    </title>
    <link rel=\"stylesheet\" href=\"{{ asset('font-awesome/css/font-awesome.min.css') }}\">
    <link rel=\"stylesheet\" href=\"{{ asset('css/menu_left_panel.css') }}\">
    {% block stylesheets %}{% endblock %}
    {% block javascripts %}{% endblock %}
    <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('icon.ico') }}\"/>
  </head>
  <body>
    <style type=\"text/css\"></style>
    <div id=\"cssmenu\">
      <ul>
        <li>
          <a href=\"{{ path('panel_membre') }}\">
            <i class=\"fa fa-fw fa-3x fa-tachometer\"></i><br/>
            Tableau de Bord</a>
        </li>
        <li class=\"has-sub\">
          <a href=\"{{ path('re_ssources') }}\">
            <i class=\"fa fa-fw fa-3x fa-folder-open-o\"></i><br/>
            Ressources</a>
          <!--<ul>
            <li class=\"has-sub\">
              <a href=\"#\">Menu 1</a>
               <ul>
                <li>
                  <a href=\"#\">Menu 1.1</a>
                </li>
                <li>
                  <a href=\"#\">Menu 1.2</a>
                </li>
              </ul>
            </li>
            <li>
              <a href=\"#\">Menu 2</a>
            </li>
      </ul>-->
        </li>
        <li>
          <a href=\"{{ path('su_pport') }}\">
            <i class=\"fa fa-cog fa-spin fa-3x fa-fw\"></i><br/>
            <span class=\"sr-only\">Loading...</span>
            {# }<i class=\"fa far fa-fw fa-support\"></i> #}
            Support</a>
        </li>
        <li>
          <a href=\"{{ path('f_aq') }}\">
            <i class=\"fa fa-fw fa-3x fa-phone\"></i><br/>
            FAQ</a>
        </li>
        {% block login %}{% endblock %}
      </ul>
    </div>

    <div id=\"view_right\">

      {% block body %}{% endblock %}
      {% block log %}{% endblock %}
    </div>

  </body>
</html>
", "base.menu.html.twig", "/opt/lampp/htdocs/3c0m/app/Resources/views/base.menu.html.twig");
    }
}
