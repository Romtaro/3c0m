<?php

/* basevisitor.menu.html.twig */
class __TwigTemplate_a69799430a8e8d63e969055191bd7dda5c6949b91c8ef53993b6d9c6880b60bb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8694da728e2546c5172052e02836d92e98218e8765ffeb50f6b3c584c8ff2bcb = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8694da728e2546c5172052e02836d92e98218e8765ffeb50f6b3c584c8ff2bcb->enter($__internal_8694da728e2546c5172052e02836d92e98218e8765ffeb50f6b3c584c8ff2bcb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "basevisitor.menu.html.twig"));

        $__internal_e9ce1cdaf2cda373228aeb28b3875f6a3c51887c5e62d022147099255ba45c02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e9ce1cdaf2cda373228aeb28b3875f6a3c51887c5e62d022147099255ba45c02->enter($__internal_e9ce1cdaf2cda373228aeb28b3875f6a3c51887c5e62d022147099255ba45c02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "basevisitor.menu.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
  <head>
    <meta charset=\"UTF-8\"/>

    <title>
      ";
        // line 7
        $this->displayBlock('title', $context, $blocks);
        // line 10
        echo "    </title>
    <link rel=\"stylesheet\" href=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("font-awesome/css/font-awesome.min.css"), "html", null, true);
        echo "\">
    <link rel=\"stylesheet\" href=\"";
        // line 12
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/menu_left_panel.css"), "html", null, true);
        echo "\">
    ";
        // line 13
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 14
        echo "    ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 15
        echo "    <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("icon.ico"), "html", null, true);
        echo "\"/>
  </head>
  <body>
    <style type=\"text/css\"></style>
    <div id=\"cssmenu\">
      <ul>
        <li class=\"active\">
          <a class=\"ww\" href=\"";
        // line 22
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("lo_gin");
        echo "\">Connexion</a>
        </li>

      </ul>
    </div>

    <div id=\"view_right\">

      ";
        // line 30
        $this->displayBlock('body', $context, $blocks);
        // line 31
        echo "
    </div>

  </body>
</html>
";
        
        $__internal_8694da728e2546c5172052e02836d92e98218e8765ffeb50f6b3c584c8ff2bcb->leave($__internal_8694da728e2546c5172052e02836d92e98218e8765ffeb50f6b3c584c8ff2bcb_prof);

        
        $__internal_e9ce1cdaf2cda373228aeb28b3875f6a3c51887c5e62d022147099255ba45c02->leave($__internal_e9ce1cdaf2cda373228aeb28b3875f6a3c51887c5e62d022147099255ba45c02_prof);

    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        $__internal_9c79a63f6052c859654fb1c3d5efac0a3ffc62bd4ff3ab4bce87ec358be78585 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9c79a63f6052c859654fb1c3d5efac0a3ffc62bd4ff3ab4bce87ec358be78585->enter($__internal_9c79a63f6052c859654fb1c3d5efac0a3ffc62bd4ff3ab4bce87ec358be78585_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_2e88aa97f1fb8e1875ef58287445abdd17f022cc24a69751d205896079460a39 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2e88aa97f1fb8e1875ef58287445abdd17f022cc24a69751d205896079460a39->enter($__internal_2e88aa97f1fb8e1875ef58287445abdd17f022cc24a69751d205896079460a39_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 8
        echo "        3c0m - SAV - Connexion
      ";
        
        $__internal_2e88aa97f1fb8e1875ef58287445abdd17f022cc24a69751d205896079460a39->leave($__internal_2e88aa97f1fb8e1875ef58287445abdd17f022cc24a69751d205896079460a39_prof);

        
        $__internal_9c79a63f6052c859654fb1c3d5efac0a3ffc62bd4ff3ab4bce87ec358be78585->leave($__internal_9c79a63f6052c859654fb1c3d5efac0a3ffc62bd4ff3ab4bce87ec358be78585_prof);

    }

    // line 13
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_82d255f93a19985ac5fa98b0e808cda8b53adcfb15f6580f7a2bb897c900f97d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_82d255f93a19985ac5fa98b0e808cda8b53adcfb15f6580f7a2bb897c900f97d->enter($__internal_82d255f93a19985ac5fa98b0e808cda8b53adcfb15f6580f7a2bb897c900f97d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_2a1e180c29d5953ce426d5f8050b465324639493dd5b380fb13cb04e5518a59b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2a1e180c29d5953ce426d5f8050b465324639493dd5b380fb13cb04e5518a59b->enter($__internal_2a1e180c29d5953ce426d5f8050b465324639493dd5b380fb13cb04e5518a59b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_2a1e180c29d5953ce426d5f8050b465324639493dd5b380fb13cb04e5518a59b->leave($__internal_2a1e180c29d5953ce426d5f8050b465324639493dd5b380fb13cb04e5518a59b_prof);

        
        $__internal_82d255f93a19985ac5fa98b0e808cda8b53adcfb15f6580f7a2bb897c900f97d->leave($__internal_82d255f93a19985ac5fa98b0e808cda8b53adcfb15f6580f7a2bb897c900f97d_prof);

    }

    // line 14
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_0f3635c4619fee6a1d25f10bb8fd522c64082d9c588412b90a43c550ef3c8ee4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0f3635c4619fee6a1d25f10bb8fd522c64082d9c588412b90a43c550ef3c8ee4->enter($__internal_0f3635c4619fee6a1d25f10bb8fd522c64082d9c588412b90a43c550ef3c8ee4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_584e6309d8f9c7b6b80ed1a7d0d91b5280674f12331c33e8b2dacf47cd398952 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_584e6309d8f9c7b6b80ed1a7d0d91b5280674f12331c33e8b2dacf47cd398952->enter($__internal_584e6309d8f9c7b6b80ed1a7d0d91b5280674f12331c33e8b2dacf47cd398952_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_584e6309d8f9c7b6b80ed1a7d0d91b5280674f12331c33e8b2dacf47cd398952->leave($__internal_584e6309d8f9c7b6b80ed1a7d0d91b5280674f12331c33e8b2dacf47cd398952_prof);

        
        $__internal_0f3635c4619fee6a1d25f10bb8fd522c64082d9c588412b90a43c550ef3c8ee4->leave($__internal_0f3635c4619fee6a1d25f10bb8fd522c64082d9c588412b90a43c550ef3c8ee4_prof);

    }

    // line 30
    public function block_body($context, array $blocks = array())
    {
        $__internal_4a95590965159eeab7443a4a2d7baae866f52beb16f52c538303ea9c85fc4389 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4a95590965159eeab7443a4a2d7baae866f52beb16f52c538303ea9c85fc4389->enter($__internal_4a95590965159eeab7443a4a2d7baae866f52beb16f52c538303ea9c85fc4389_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_3c09184410d2fabb8ffd4c03b0a41cfc4fc7324f7864b353a4b7f0fdb98cb4ce = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3c09184410d2fabb8ffd4c03b0a41cfc4fc7324f7864b353a4b7f0fdb98cb4ce->enter($__internal_3c09184410d2fabb8ffd4c03b0a41cfc4fc7324f7864b353a4b7f0fdb98cb4ce_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_3c09184410d2fabb8ffd4c03b0a41cfc4fc7324f7864b353a4b7f0fdb98cb4ce->leave($__internal_3c09184410d2fabb8ffd4c03b0a41cfc4fc7324f7864b353a4b7f0fdb98cb4ce_prof);

        
        $__internal_4a95590965159eeab7443a4a2d7baae866f52beb16f52c538303ea9c85fc4389->leave($__internal_4a95590965159eeab7443a4a2d7baae866f52beb16f52c538303ea9c85fc4389_prof);

    }

    public function getTemplateName()
    {
        return "basevisitor.menu.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  148 => 30,  131 => 14,  114 => 13,  103 => 8,  94 => 7,  79 => 31,  77 => 30,  66 => 22,  55 => 15,  52 => 14,  50 => 13,  46 => 12,  42 => 11,  39 => 10,  37 => 7,  29 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
  <head>
    <meta charset=\"UTF-8\"/>

    <title>
      {% block title %}
        3c0m - SAV - Connexion
      {% endblock %}
    </title>
    <link rel=\"stylesheet\" href=\"{{ asset('font-awesome/css/font-awesome.min.css') }}\">
    <link rel=\"stylesheet\" href=\"{{ asset('css/menu_left_panel.css') }}\">
    {% block stylesheets %}{% endblock %}
    {% block javascripts %}{% endblock %}
    <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('icon.ico') }}\"/>
  </head>
  <body>
    <style type=\"text/css\"></style>
    <div id=\"cssmenu\">
      <ul>
        <li class=\"active\">
          <a class=\"ww\" href=\"{{ path('lo_gin') }}\">Connexion</a>
        </li>

      </ul>
    </div>

    <div id=\"view_right\">

      {% block body %}{% endblock %}

    </div>

  </body>
</html>
", "basevisitor.menu.html.twig", "/opt/lampp/htdocs/3c0m/app/Resources/views/basevisitor.menu.html.twig");
    }
}
