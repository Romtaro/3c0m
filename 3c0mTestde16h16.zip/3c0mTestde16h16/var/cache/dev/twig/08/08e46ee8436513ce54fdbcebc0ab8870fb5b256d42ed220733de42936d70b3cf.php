<?php

/* ENTSiteBundle:Membre:login.html.twig */
class __TwigTemplate_0b3d729315902c09f9a36894c3dff79e2d0a35e8c8f79f7a30554fa4d3b7a9be extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("basevisitor.menu.html.twig", "ENTSiteBundle:Membre:login.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "basevisitor.menu.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1f086bf77878374effeef0d3346f2578deb6bb50c1f1173ef9ec4dc8df1b8d5a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1f086bf77878374effeef0d3346f2578deb6bb50c1f1173ef9ec4dc8df1b8d5a->enter($__internal_1f086bf77878374effeef0d3346f2578deb6bb50c1f1173ef9ec4dc8df1b8d5a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "ENTSiteBundle:Membre:login.html.twig"));

        $__internal_7963ac0039849515abce43a22de93df959a795d4f30abfed8187ba1c722b8216 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7963ac0039849515abce43a22de93df959a795d4f30abfed8187ba1c722b8216->enter($__internal_7963ac0039849515abce43a22de93df959a795d4f30abfed8187ba1c722b8216_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "ENTSiteBundle:Membre:login.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_1f086bf77878374effeef0d3346f2578deb6bb50c1f1173ef9ec4dc8df1b8d5a->leave($__internal_1f086bf77878374effeef0d3346f2578deb6bb50c1f1173ef9ec4dc8df1b8d5a_prof);

        
        $__internal_7963ac0039849515abce43a22de93df959a795d4f30abfed8187ba1c722b8216->leave($__internal_7963ac0039849515abce43a22de93df959a795d4f30abfed8187ba1c722b8216_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_bdf351853af850f81031fa3d3209c0f3e3ab731f5408a7f9b930d5717ef400d2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_bdf351853af850f81031fa3d3209c0f3e3ab731f5408a7f9b930d5717ef400d2->enter($__internal_bdf351853af850f81031fa3d3209c0f3e3ab731f5408a7f9b930d5717ef400d2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_c2dc5b1cad20ade478b6be1cb61acbc659e337e1edfd5fdd5928bbe05cd4782c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c2dc5b1cad20ade478b6be1cb61acbc659e337e1edfd5fdd5928bbe05cd4782c->enter($__internal_c2dc5b1cad20ade478b6be1cb61acbc659e337e1edfd5fdd5928bbe05cd4782c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "3c0m - Connexion";
        
        $__internal_c2dc5b1cad20ade478b6be1cb61acbc659e337e1edfd5fdd5928bbe05cd4782c->leave($__internal_c2dc5b1cad20ade478b6be1cb61acbc659e337e1edfd5fdd5928bbe05cd4782c_prof);

        
        $__internal_bdf351853af850f81031fa3d3209c0f3e3ab731f5408a7f9b930d5717ef400d2->leave($__internal_bdf351853af850f81031fa3d3209c0f3e3ab731f5408a7f9b930d5717ef400d2_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_620b2fa6a81c81ce49d598a74cd6ba857ea8db6cc9306b263f4d49ae7fdff342 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_620b2fa6a81c81ce49d598a74cd6ba857ea8db6cc9306b263f4d49ae7fdff342->enter($__internal_620b2fa6a81c81ce49d598a74cd6ba857ea8db6cc9306b263f4d49ae7fdff342_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_6ce337c32cafb62460413c061282546eee350ef3b8e96721317a33ec9577fa46 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6ce337c32cafb62460413c061282546eee350ef3b8e96721317a33ec9577fa46->enter($__internal_6ce337c32cafb62460413c061282546eee350ef3b8e96721317a33ec9577fa46_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        echo "<link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/styles.css"), "html", null, true);
        echo "\">";
        
        $__internal_6ce337c32cafb62460413c061282546eee350ef3b8e96721317a33ec9577fa46->leave($__internal_6ce337c32cafb62460413c061282546eee350ef3b8e96721317a33ec9577fa46_prof);

        
        $__internal_620b2fa6a81c81ce49d598a74cd6ba857ea8db6cc9306b263f4d49ae7fdff342->leave($__internal_620b2fa6a81c81ce49d598a74cd6ba857ea8db6cc9306b263f4d49ae7fdff342_prof);

    }

    // line 7
    public function block_body($context, array $blocks = array())
    {
        $__internal_0389f4f3f3690f339c8afe98c2e7b2efd928d36dd8972e13dabfefdceca368fe = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0389f4f3f3690f339c8afe98c2e7b2efd928d36dd8972e13dabfefdceca368fe->enter($__internal_0389f4f3f3690f339c8afe98c2e7b2efd928d36dd8972e13dabfefdceca368fe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_aa7f29e5b23c90c31930e12393419ca9b50122992875bf18987b4a14b343bb08 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_aa7f29e5b23c90c31930e12393419ca9b50122992875bf18987b4a14b343bb08->enter($__internal_aa7f29e5b23c90c31930e12393419ca9b50122992875bf18987b4a14b343bb08_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 8
        echo "  <div class=\"lastuser\">
    <h3>
      Dernier Username :
      ";
        // line 12
        echo "    </h3>
  </div>
  ";
        // line 17
        echo "
  ";
        // line 18
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start', array("attr" => array("class" => "bloggerr")));
        echo "
  ";
        // line 19
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'errors');
        echo "

  ";
        // line 21
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "pseudo", array()), 'row', array("label" => "Pseudo"));
        echo "
  ";
        // line 22
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "email", array()), 'row');
        echo "
  ";
        // line 23
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "mdp", array()), 'row', array("label" => "Mot de passe", "attr" => array("type" => "password")));
        echo "
  ";
        // line 26
        echo "  ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "submit", array()), 'row', array("label" => "Connexion"));
        echo "

  pseudo__: juju<br/>
  email___: julien.cottet@gmail.com<br/>
  mdp____: soleil<br/>
  ";
        // line 31
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'rest');
        echo "
  ";
        // line 32
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "
  ";
        // line 33
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(range(0, 100));
        foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
            // line 34
            echo "    ";
            // line 35
            echo "  ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        
        $__internal_aa7f29e5b23c90c31930e12393419ca9b50122992875bf18987b4a14b343bb08->leave($__internal_aa7f29e5b23c90c31930e12393419ca9b50122992875bf18987b4a14b343bb08_prof);

        
        $__internal_0389f4f3f3690f339c8afe98c2e7b2efd928d36dd8972e13dabfefdceca368fe->leave($__internal_0389f4f3f3690f339c8afe98c2e7b2efd928d36dd8972e13dabfefdceca368fe_prof);

    }

    public function getTemplateName()
    {
        return "ENTSiteBundle:Membre:login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  145 => 35,  143 => 34,  139 => 33,  135 => 32,  131 => 31,  122 => 26,  118 => 23,  114 => 22,  110 => 21,  105 => 19,  101 => 18,  98 => 17,  94 => 12,  89 => 8,  80 => 7,  60 => 6,  42 => 5,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'basevisitor.menu.html.twig' %}
{# app/Resources/views/security/login.html.twig #}
{# ... you will probably extend your base template, like base.html.twig #}

{% block title %}3c0m - Connexion{% endblock %}
{% block stylesheets %}<link rel=\"stylesheet\" href=\"{{ asset('css/styles.css') }}\">{% endblock %}
{% block body %}
  <div class=\"lastuser\">
    <h3>
      Dernier Username :
      {# {{ test|upper }} #}
    </h3>
  </div>
  {# {% if error %}
    <div>{{ error.messageKey|trans(error.messageData, 'security') }}</div>
  {% endif %} #}

  {{ form_start(form, {'attr' : { 'class' : 'bloggerr'}}) }}
  {{ form_errors(form) }}

  {{ form_row(form.pseudo, {'label': 'Pseudo' }) }}
  {{ form_row(form.email) }}
  {{ form_row(form.mdp, {'label': 'Mot de passe', 'attr' : { 'type' : 'password' }}) }}
  {#   {{ form_row(form.subject) }}
  {{ form_row(form.body) }}#}
  {{ form_row(form.submit, { 'label': 'Connexion' }) }}

  pseudo__: juju<br/>
  email___: julien.cottet@gmail.com<br/>
  mdp____: soleil<br/>
  {{ form_rest(form) }}
  {{ form_end(form) }}
  {% for i in 0..100 %}
    {#{{ i  }}#}
  {% endfor %}
{% endblock %}

{##}
", "ENTSiteBundle:Membre:login.html.twig", "/opt/lampp/htdocs/3c0m/src/ENT/SiteBundle/Resources/views/Membre/login.html.twig");
    }
}
