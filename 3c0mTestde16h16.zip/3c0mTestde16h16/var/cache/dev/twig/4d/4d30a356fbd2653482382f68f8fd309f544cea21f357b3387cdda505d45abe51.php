<?php

/* ENTSiteBundle:Membre:logi.html.twig */
class __TwigTemplate_b5d7291d185989608e4a0ece1309a7eae16f36db950fb9d255b2ca30a8f7e7a0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("ENTSiteBundle:Membre:ressources.html.twig", "ENTSiteBundle:Membre:logi.html.twig", 1);
        $this->blocks = array(
            'log' => array($this, 'block_log'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "ENTSiteBundle:Membre:ressources.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_aea6177da762c503e479b4b7991391c11dcf65161afe821add2e72b7a1265b3c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_aea6177da762c503e479b4b7991391c11dcf65161afe821add2e72b7a1265b3c->enter($__internal_aea6177da762c503e479b4b7991391c11dcf65161afe821add2e72b7a1265b3c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "ENTSiteBundle:Membre:logi.html.twig"));

        $__internal_29f11180bbbd3e246ea971baa86d11877ed71fbb8c5c76c1aecc57b875e97d84 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_29f11180bbbd3e246ea971baa86d11877ed71fbb8c5c76c1aecc57b875e97d84->enter($__internal_29f11180bbbd3e246ea971baa86d11877ed71fbb8c5c76c1aecc57b875e97d84_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "ENTSiteBundle:Membre:logi.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_aea6177da762c503e479b4b7991391c11dcf65161afe821add2e72b7a1265b3c->leave($__internal_aea6177da762c503e479b4b7991391c11dcf65161afe821add2e72b7a1265b3c_prof);

        
        $__internal_29f11180bbbd3e246ea971baa86d11877ed71fbb8c5c76c1aecc57b875e97d84->leave($__internal_29f11180bbbd3e246ea971baa86d11877ed71fbb8c5c76c1aecc57b875e97d84_prof);

    }

    // line 3
    public function block_log($context, array $blocks = array())
    {
        $__internal_c2c2daca41485452e5ea0da6299cfcea472388de1dc5a0c74b089b099f16e11d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c2c2daca41485452e5ea0da6299cfcea472388de1dc5a0c74b089b099f16e11d->enter($__internal_c2c2daca41485452e5ea0da6299cfcea472388de1dc5a0c74b089b099f16e11d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "log"));

        $__internal_dda64932a24ccbff427014a6dce591a28b39490c61e40e268ae3e4a3141e0239 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_dda64932a24ccbff427014a6dce591a28b39490c61e40e268ae3e4a3141e0239->enter($__internal_dda64932a24ccbff427014a6dce591a28b39490c61e40e268ae3e4a3141e0239_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "log"));

        // line 4
        echo "<div id=\"\" style=\"color:white;\">
  <h1>
    ";
        // line 6
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["nom"]) ? $context["nom"] : $this->getContext($context, "nom")));
        foreach ($context['_seq'] as $context["_key"] => $context["cont"]) {
            // line 7
            echo "  ";
            // line 8
            echo "    |
  ";
            // line 10
            echo "    |

    ";
            // line 12
            echo twig_escape_filter($this->env, $context["cont"], "html", null, true);
            echo "
    |

  ";
            // line 16
            echo "    |
    ";
            // line 18
            echo "    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['cont'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 19
        echo "  </h1>
</div>
";
        
        $__internal_dda64932a24ccbff427014a6dce591a28b39490c61e40e268ae3e4a3141e0239->leave($__internal_dda64932a24ccbff427014a6dce591a28b39490c61e40e268ae3e4a3141e0239_prof);

        
        $__internal_c2c2daca41485452e5ea0da6299cfcea472388de1dc5a0c74b089b099f16e11d->leave($__internal_c2c2daca41485452e5ea0da6299cfcea472388de1dc5a0c74b089b099f16e11d_prof);

    }

    public function getTemplateName()
    {
        return "ENTSiteBundle:Membre:logi.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  81 => 19,  75 => 18,  72 => 16,  66 => 12,  62 => 10,  59 => 8,  57 => 7,  53 => 6,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"ENTSiteBundle:Membre:ressources.html.twig\" %}

{% block log %}
<div id=\"\" style=\"color:white;\">
  <h1>
    {% for cont in nom %}
  {#   {{ id_doc }}#}
    |
  {#   {{ id_cat }}#}
    |

    {{ cont }}
    |

  {#   {{ taille }}#}
    |
    {#  {{ data_enrg }}#}
    {% endfor %}
  </h1>
</div>
{% endblock %}
", "ENTSiteBundle:Membre:logi.html.twig", "/opt/lampp/htdocs/3c0m/src/ENT/SiteBundle/Resources/views/Membre/logi.html.twig");
    }
}
