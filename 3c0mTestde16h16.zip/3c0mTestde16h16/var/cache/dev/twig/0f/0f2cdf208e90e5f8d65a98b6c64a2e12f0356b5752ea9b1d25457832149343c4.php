<?php

/* ENTSiteBundle:Membre:faq.html.twig */
class __TwigTemplate_b807ff7086b3b75917caac0cb2aa1564c73d7ff4049d6967030b697804af21b6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.menu.html.twig", "ENTSiteBundle:Membre:faq.html.twig", 1);
        $this->blocks = array(
            'login' => array($this, 'block_login'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.menu.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d2a5ba9494f5a230b0d5417f3ae6d46816a75d442e50d67f1e224eaeecdf8e2a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d2a5ba9494f5a230b0d5417f3ae6d46816a75d442e50d67f1e224eaeecdf8e2a->enter($__internal_d2a5ba9494f5a230b0d5417f3ae6d46816a75d442e50d67f1e224eaeecdf8e2a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "ENTSiteBundle:Membre:faq.html.twig"));

        $__internal_682bea0251f578fba6db0fc4548d99a6bf455b3d4058ba9b6d32444f25aab5c8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_682bea0251f578fba6db0fc4548d99a6bf455b3d4058ba9b6d32444f25aab5c8->enter($__internal_682bea0251f578fba6db0fc4548d99a6bf455b3d4058ba9b6d32444f25aab5c8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "ENTSiteBundle:Membre:faq.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_d2a5ba9494f5a230b0d5417f3ae6d46816a75d442e50d67f1e224eaeecdf8e2a->leave($__internal_d2a5ba9494f5a230b0d5417f3ae6d46816a75d442e50d67f1e224eaeecdf8e2a_prof);

        
        $__internal_682bea0251f578fba6db0fc4548d99a6bf455b3d4058ba9b6d32444f25aab5c8->leave($__internal_682bea0251f578fba6db0fc4548d99a6bf455b3d4058ba9b6d32444f25aab5c8_prof);

    }

    // line 2
    public function block_login($context, array $blocks = array())
    {
        $__internal_92e4607f81fdc27379f98ea510d068d3b6d459598966d75130db75877fdc10bf = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_92e4607f81fdc27379f98ea510d068d3b6d459598966d75130db75877fdc10bf->enter($__internal_92e4607f81fdc27379f98ea510d068d3b6d459598966d75130db75877fdc10bf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "login"));

        $__internal_bdb5eecd4962a7b8d9a9cabb3dc5cfafe69c3e766a66698cd3da28a1e00e8dde = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bdb5eecd4962a7b8d9a9cabb3dc5cfafe69c3e766a66698cd3da28a1e00e8dde->enter($__internal_bdb5eecd4962a7b8d9a9cabb3dc5cfafe69c3e766a66698cd3da28a1e00e8dde_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "login"));

        // line 3
        echo "
  <li class=\"active\">
    <a class=\"ww\" href=\"";
        // line 5
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("lo_gin");
        echo "\">Déconnexion</a>
  </li>

";
        
        $__internal_bdb5eecd4962a7b8d9a9cabb3dc5cfafe69c3e766a66698cd3da28a1e00e8dde->leave($__internal_bdb5eecd4962a7b8d9a9cabb3dc5cfafe69c3e766a66698cd3da28a1e00e8dde_prof);

        
        $__internal_92e4607f81fdc27379f98ea510d068d3b6d459598966d75130db75877fdc10bf->leave($__internal_92e4607f81fdc27379f98ea510d068d3b6d459598966d75130db75877fdc10bf_prof);

    }

    // line 9
    public function block_body($context, array $blocks = array())
    {
        $__internal_99d13d118d1380dee080173bda0c513db2f481ff6ef10e9ec89b7ad9e19c2afd = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_99d13d118d1380dee080173bda0c513db2f481ff6ef10e9ec89b7ad9e19c2afd->enter($__internal_99d13d118d1380dee080173bda0c513db2f481ff6ef10e9ec89b7ad9e19c2afd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_cd953238d56133fdcbe928710b0222143fc7f4ba8aa65946879d813d8d0b3d5f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cd953238d56133fdcbe928710b0222143fc7f4ba8aa65946879d813d8d0b3d5f->enter($__internal_cd953238d56133fdcbe928710b0222143fc7f4ba8aa65946879d813d8d0b3d5f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 10
        echo "  faq
  <div id=\"test\">
    <h1>
      ";
        // line 13
        echo twig_escape_filter($this->env, twig_upper_filter($this->env, (isset($context["test"]) ? $context["test"] : $this->getContext($context, "test"))), "html", null, true);
        echo "
    </h1>
  </div>
";
        
        $__internal_cd953238d56133fdcbe928710b0222143fc7f4ba8aa65946879d813d8d0b3d5f->leave($__internal_cd953238d56133fdcbe928710b0222143fc7f4ba8aa65946879d813d8d0b3d5f_prof);

        
        $__internal_99d13d118d1380dee080173bda0c513db2f481ff6ef10e9ec89b7ad9e19c2afd->leave($__internal_99d13d118d1380dee080173bda0c513db2f481ff6ef10e9ec89b7ad9e19c2afd_prof);

    }

    public function getTemplateName()
    {
        return "ENTSiteBundle:Membre:faq.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  82 => 13,  77 => 10,  68 => 9,  54 => 5,  50 => 3,  41 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.menu.html.twig' %}
{% block login %}

  <li class=\"active\">
    <a class=\"ww\" href=\"{{ path('lo_gin') }}\">Déconnexion</a>
  </li>

{% endblock %}
{% block body %}
  faq
  <div id=\"test\">
    <h1>
      {{ test|upper }}
    </h1>
  </div>
{% endblock %}
", "ENTSiteBundle:Membre:faq.html.twig", "/opt/lampp/htdocs/3c0m/src/ENT/SiteBundle/Resources/views/Membre/faq.html.twig");
    }
}
