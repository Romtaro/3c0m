<?php

/* ENTSiteBundle:Membre:panelmembre.html.twig */
class __TwigTemplate_fc75621cb716cecc028ae9c0dc51dba84ec3d96b1926d87fe03f3572ae7fd559 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.menu.html.twig", "ENTSiteBundle:Membre:panelmembre.html.twig", 1);
        $this->blocks = array(
            'stylesheets' => array($this, 'block_stylesheets'),
            'login' => array($this, 'block_login'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.menu.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0ad02cbbd91435f5d2b9a02e7e2f3ecc3786807267400e02db56f71ff99b1aa5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0ad02cbbd91435f5d2b9a02e7e2f3ecc3786807267400e02db56f71ff99b1aa5->enter($__internal_0ad02cbbd91435f5d2b9a02e7e2f3ecc3786807267400e02db56f71ff99b1aa5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "ENTSiteBundle:Membre:panelmembre.html.twig"));

        $__internal_b160cf9a2733e4253576c9812b6ae48790a074c779c33181cd95ebb0a3edb270 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b160cf9a2733e4253576c9812b6ae48790a074c779c33181cd95ebb0a3edb270->enter($__internal_b160cf9a2733e4253576c9812b6ae48790a074c779c33181cd95ebb0a3edb270_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "ENTSiteBundle:Membre:panelmembre.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_0ad02cbbd91435f5d2b9a02e7e2f3ecc3786807267400e02db56f71ff99b1aa5->leave($__internal_0ad02cbbd91435f5d2b9a02e7e2f3ecc3786807267400e02db56f71ff99b1aa5_prof);

        
        $__internal_b160cf9a2733e4253576c9812b6ae48790a074c779c33181cd95ebb0a3edb270->leave($__internal_b160cf9a2733e4253576c9812b6ae48790a074c779c33181cd95ebb0a3edb270_prof);

    }

    // line 2
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_ca3e30f6f9008aa8fd0e83036e0fa648c3334767b8d1424f2f9ba90110124223 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ca3e30f6f9008aa8fd0e83036e0fa648c3334767b8d1424f2f9ba90110124223->enter($__internal_ca3e30f6f9008aa8fd0e83036e0fa648c3334767b8d1424f2f9ba90110124223_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_72cfddead04359c99c79efe6cadace0f709e4acb287a11c1fa6ab3b11368a837 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_72cfddead04359c99c79efe6cadace0f709e4acb287a11c1fa6ab3b11368a837->enter($__internal_72cfddead04359c99c79efe6cadace0f709e4acb287a11c1fa6ab3b11368a837_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_72cfddead04359c99c79efe6cadace0f709e4acb287a11c1fa6ab3b11368a837->leave($__internal_72cfddead04359c99c79efe6cadace0f709e4acb287a11c1fa6ab3b11368a837_prof);

        
        $__internal_ca3e30f6f9008aa8fd0e83036e0fa648c3334767b8d1424f2f9ba90110124223->leave($__internal_ca3e30f6f9008aa8fd0e83036e0fa648c3334767b8d1424f2f9ba90110124223_prof);

    }

    // line 3
    public function block_login($context, array $blocks = array())
    {
        $__internal_ada48e1bfd64314d043786f5d66b820376147a97cb33259cba4a21207519d4bd = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ada48e1bfd64314d043786f5d66b820376147a97cb33259cba4a21207519d4bd->enter($__internal_ada48e1bfd64314d043786f5d66b820376147a97cb33259cba4a21207519d4bd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "login"));

        $__internal_87674548effa3879646dae7e2d5540e7806128a4a433ad9ebdc3e338476e80f3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_87674548effa3879646dae7e2d5540e7806128a4a433ad9ebdc3e338476e80f3->enter($__internal_87674548effa3879646dae7e2d5540e7806128a4a433ad9ebdc3e338476e80f3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "login"));

        // line 4
        echo "
  <li class=\"active\">
    <a class=\"ww\" href=\"";
        // line 6
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("lo_gin");
        echo "\">Déconnexion</a>
  </li>

";
        
        $__internal_87674548effa3879646dae7e2d5540e7806128a4a433ad9ebdc3e338476e80f3->leave($__internal_87674548effa3879646dae7e2d5540e7806128a4a433ad9ebdc3e338476e80f3_prof);

        
        $__internal_ada48e1bfd64314d043786f5d66b820376147a97cb33259cba4a21207519d4bd->leave($__internal_ada48e1bfd64314d043786f5d66b820376147a97cb33259cba4a21207519d4bd_prof);

    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        $__internal_aef1d716fdbb1096479517aefdf2caedec6f19917dd041b93a28c7814e5e432c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_aef1d716fdbb1096479517aefdf2caedec6f19917dd041b93a28c7814e5e432c->enter($__internal_aef1d716fdbb1096479517aefdf2caedec6f19917dd041b93a28c7814e5e432c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_156ea8c00faace2eaf5c9fd4c28c8f81b6d42d0d0ac6b9e031beeeaf8918df27 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_156ea8c00faace2eaf5c9fd4c28c8f81b6d42d0d0ac6b9e031beeeaf8918df27->enter($__internal_156ea8c00faace2eaf5c9fd4c28c8f81b6d42d0d0ac6b9e031beeeaf8918df27_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 11
        echo "  panelmembre
  <div id=\"test\">
    ";
        // line 18
        echo "
    ";
        // line 19
        if ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("ROLE_USER")) {
            // line 20
            echo "      <a href=\"";
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("lo_gin");
            echo "\">Delete</a>
    ";
        }
        // line 22
        echo "  </div>

  <div id=\"\" style=\"\">
    <ul >
    <li>
      <a href=\"admin\" style=\"height:30px;padding-top:3%;padding-bottom:1%;\">
        <i class=\"fa fa-cog fa-spin fa-lg fa-fw\" aria-hidden=\"true\"></i>
        Go to Tableau de Bord Admin (panelAdmin)</a>
    </li>
  </ul>
</div>
";
        
        $__internal_156ea8c00faace2eaf5c9fd4c28c8f81b6d42d0d0ac6b9e031beeeaf8918df27->leave($__internal_156ea8c00faace2eaf5c9fd4c28c8f81b6d42d0d0ac6b9e031beeeaf8918df27_prof);

        
        $__internal_aef1d716fdbb1096479517aefdf2caedec6f19917dd041b93a28c7814e5e432c->leave($__internal_aef1d716fdbb1096479517aefdf2caedec6f19917dd041b93a28c7814e5e432c_prof);

    }

    public function getTemplateName()
    {
        return "ENTSiteBundle:Membre:panelmembre.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  110 => 22,  104 => 20,  102 => 19,  99 => 18,  95 => 11,  86 => 10,  72 => 6,  68 => 4,  59 => 3,  42 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.menu.html.twig' %}
{% block stylesheets %}{% endblock %}
{% block login %}

  <li class=\"active\">
    <a class=\"ww\" href=\"{{ path('lo_gin') }}\">Déconnexion</a>
  </li>

{% endblock %}
{% block body %}
  panelmembre
  <div id=\"test\">
    {#<h1>
      {{ test|upper }}
      :
      {{ pseudo|capitalize }}
    </h1>#}

    {% if is_granted('ROLE_USER') %}
      <a href=\"{{ path('lo_gin') }}\">Delete</a>
    {% endif %}
  </div>

  <div id=\"\" style=\"\">
    <ul >
    <li>
      <a href=\"admin\" style=\"height:30px;padding-top:3%;padding-bottom:1%;\">
        <i class=\"fa fa-cog fa-spin fa-lg fa-fw\" aria-hidden=\"true\"></i>
        Go to Tableau de Bord Admin (panelAdmin)</a>
    </li>
  </ul>
</div>
{% endblock %}
", "ENTSiteBundle:Membre:panelmembre.html.twig", "/opt/lampp/htdocs/3c0m/src/ENT/SiteBundle/Resources/views/Membre/panelmembre.html.twig");
    }
}
