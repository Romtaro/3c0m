<?php

/* ENTSiteBundle:Membre:ressources.html.twig */
class __TwigTemplate_cd40a03957e0ad54d159bde47ce50f6328a76e3c2da1427e06080f87c422e6a5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.menu.html.twig", "ENTSiteBundle:Membre:ressources.html.twig", 1);
        $this->blocks = array(
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
            'body' => array($this, 'block_body'),
            'log' => array($this, 'block_log'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.menu.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_cebf0e9a16c7de8943a3dd77392a481d3a49f72dd6b4474f4693e8b61e7ade5f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cebf0e9a16c7de8943a3dd77392a481d3a49f72dd6b4474f4693e8b61e7ade5f->enter($__internal_cebf0e9a16c7de8943a3dd77392a481d3a49f72dd6b4474f4693e8b61e7ade5f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "ENTSiteBundle:Membre:ressources.html.twig"));

        $__internal_0eccef370b4d660a4c202a1a72be3627d959f5f49bc3629bd0c3e7f62683eab9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0eccef370b4d660a4c202a1a72be3627d959f5f49bc3629bd0c3e7f62683eab9->enter($__internal_0eccef370b4d660a4c202a1a72be3627d959f5f49bc3629bd0c3e7f62683eab9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "ENTSiteBundle:Membre:ressources.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_cebf0e9a16c7de8943a3dd77392a481d3a49f72dd6b4474f4693e8b61e7ade5f->leave($__internal_cebf0e9a16c7de8943a3dd77392a481d3a49f72dd6b4474f4693e8b61e7ade5f_prof);

        
        $__internal_0eccef370b4d660a4c202a1a72be3627d959f5f49bc3629bd0c3e7f62683eab9->leave($__internal_0eccef370b4d660a4c202a1a72be3627d959f5f49bc3629bd0c3e7f62683eab9_prof);

    }

    // line 3
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_ecb340c122cee5a0f952c73d56ba55a4d7053cc6eaed4cdc85c61acdcf074fb4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ecb340c122cee5a0f952c73d56ba55a4d7053cc6eaed4cdc85c61acdcf074fb4->enter($__internal_ecb340c122cee5a0f952c73d56ba55a4d7053cc6eaed4cdc85c61acdcf074fb4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_a65c03bdaf4e329fa43eb1d85626934ec81ca4b93c6784d860d7f43c91998fa7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a65c03bdaf4e329fa43eb1d85626934ec81ca4b93c6784d860d7f43c91998fa7->enter($__internal_a65c03bdaf4e329fa43eb1d85626934ec81ca4b93c6784d860d7f43c91998fa7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 4
        echo "  <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/dropzone.css"), "html", null, true);
        echo "\">
  <link rel=\"stylesheet\" href=\"";
        // line 5
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/styles.css"), "html", null, true);
        echo "\">
";
        
        $__internal_a65c03bdaf4e329fa43eb1d85626934ec81ca4b93c6784d860d7f43c91998fa7->leave($__internal_a65c03bdaf4e329fa43eb1d85626934ec81ca4b93c6784d860d7f43c91998fa7_prof);

        
        $__internal_ecb340c122cee5a0f952c73d56ba55a4d7053cc6eaed4cdc85c61acdcf074fb4->leave($__internal_ecb340c122cee5a0f952c73d56ba55a4d7053cc6eaed4cdc85c61acdcf074fb4_prof);

    }

    // line 8
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_178f59c1647e02e6d7f873dc1fc0a9761aee271dfd420d0921baa80a38650465 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_178f59c1647e02e6d7f873dc1fc0a9761aee271dfd420d0921baa80a38650465->enter($__internal_178f59c1647e02e6d7f873dc1fc0a9761aee271dfd420d0921baa80a38650465_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_7505dbbdfccca03ca8c695e7b4110a7eee9de7656526c283d0b0243e666bd198 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7505dbbdfccca03ca8c695e7b4110a7eee9de7656526c283d0b0243e666bd198->enter($__internal_7505dbbdfccca03ca8c695e7b4110a7eee9de7656526c283d0b0243e666bd198_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 9
        echo "  <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js\"></script>
  <script type=\"text/javascript\" src=\"";
        // line 10
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/dropzone.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_7505dbbdfccca03ca8c695e7b4110a7eee9de7656526c283d0b0243e666bd198->leave($__internal_7505dbbdfccca03ca8c695e7b4110a7eee9de7656526c283d0b0243e666bd198_prof);

        
        $__internal_178f59c1647e02e6d7f873dc1fc0a9761aee271dfd420d0921baa80a38650465->leave($__internal_178f59c1647e02e6d7f873dc1fc0a9761aee271dfd420d0921baa80a38650465_prof);

    }

    // line 13
    public function block_body($context, array $blocks = array())
    {
        $__internal_16904209fc72ed948e260589dc188c4e83ed7c4ea0af68ae86ff78d1ddb61544 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_16904209fc72ed948e260589dc188c4e83ed7c4ea0af68ae86ff78d1ddb61544->enter($__internal_16904209fc72ed948e260589dc188c4e83ed7c4ea0af68ae86ff78d1ddb61544_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_b723cbdb233aceb350cad26c43fe472255355f0805da111f1c4881afe2955e87 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b723cbdb233aceb350cad26c43fe472255355f0805da111f1c4881afe2955e87->enter($__internal_b723cbdb233aceb350cad26c43fe472255355f0805da111f1c4881afe2955e87_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 14
        echo "  <div id=\"bg\">
    <div id=\"\" style=\"color:white;\">
      <h1>
        ";
        // line 17
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["nom"]) ? $context["nom"] : $this->getContext($context, "nom")));
        foreach ($context['_seq'] as $context["_key"] => $context["contnom"]) {
            // line 18
            echo "      ";
            // line 19
            echo "        |
      ";
            // line 21
            echo "        |

        ";
            // line 23
            echo twig_escape_filter($this->env, $context["contnom"], "html", null, true);
            echo "
        |

      ";
            // line 27
            echo "        |
        ";
            // line 29
            echo "        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['contnom'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 30
        echo "      </h1>
    </div>
    ";
        // line 33
        echo "    <div class=\"dropzone my-dropzone\" id=\"form_snippet_image\" action=\"\">
      <script type=\"text/javascript\" src=\"";
        // line 34
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/dropzone.js"), "html", null, true);
        echo "\"></script>
    </div>

    <div id=\"\" style=\"\">
      <ul >
        <li>
          <a style=\"color:white;text-decoration:none;\" href=\"";
        // line 40
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("re_ssources");
        echo "\">
            <i class=\"fa fa-fw fa-lg fa-tachometer\"></i>
            Retour sur /res simple. -> redirection vers ressources_error.html.twig (error car pas d'{id} selectionné [voir les routings de notre Bundle])
          </a>
        </li>
      </ul>
    </div>

  ";
        // line 48
        $this->displayBlock('log', $context, $blocks);
        // line 68
        echo "  </div>
";
        
        $__internal_b723cbdb233aceb350cad26c43fe472255355f0805da111f1c4881afe2955e87->leave($__internal_b723cbdb233aceb350cad26c43fe472255355f0805da111f1c4881afe2955e87_prof);

        
        $__internal_16904209fc72ed948e260589dc188c4e83ed7c4ea0af68ae86ff78d1ddb61544->leave($__internal_16904209fc72ed948e260589dc188c4e83ed7c4ea0af68ae86ff78d1ddb61544_prof);

    }

    // line 48
    public function block_log($context, array $blocks = array())
    {
        $__internal_952f9eb732c419bcf8491a598e916f83429f84a5494fed8afa2bbe355a2fb831 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_952f9eb732c419bcf8491a598e916f83429f84a5494fed8afa2bbe355a2fb831->enter($__internal_952f9eb732c419bcf8491a598e916f83429f84a5494fed8afa2bbe355a2fb831_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "log"));

        $__internal_4b9937c9a8fef8079168a40f374fb15c86589e1cbaa1d629765984ac702db8d0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4b9937c9a8fef8079168a40f374fb15c86589e1cbaa1d629765984ac702db8d0->enter($__internal_4b9937c9a8fef8079168a40f374fb15c86589e1cbaa1d629765984ac702db8d0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "log"));

        // line 49
        echo "  <div id=\"\" style=\"color:white;\">
    <h1>
      ";
        // line 51
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["nom"]) ? $context["nom"] : $this->getContext($context, "nom")));
        foreach ($context['_seq'] as $context["_key"] => $context["content"]) {
            // line 52
            echo "    ";
            // line 53
            echo "      |
    ";
            // line 55
            echo "      |

    ";
            // line 57
            echo twig_escape_filter($this->env, (isset($context["nom"]) ? $context["nom"] : $this->getContext($context, "nom")), "html", null, true);
            echo "
      |

    ";
            // line 61
            echo "      |
      ";
            // line 63
            echo "      ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['content'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 64
        echo "    </h1>
  </div>

  ";
        
        $__internal_4b9937c9a8fef8079168a40f374fb15c86589e1cbaa1d629765984ac702db8d0->leave($__internal_4b9937c9a8fef8079168a40f374fb15c86589e1cbaa1d629765984ac702db8d0_prof);

        
        $__internal_952f9eb732c419bcf8491a598e916f83429f84a5494fed8afa2bbe355a2fb831->leave($__internal_952f9eb732c419bcf8491a598e916f83429f84a5494fed8afa2bbe355a2fb831_prof);

    }

    public function getTemplateName()
    {
        return "ENTSiteBundle:Membre:ressources.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  216 => 64,  210 => 63,  207 => 61,  201 => 57,  197 => 55,  194 => 53,  192 => 52,  188 => 51,  184 => 49,  175 => 48,  164 => 68,  162 => 48,  151 => 40,  142 => 34,  139 => 33,  135 => 30,  129 => 29,  126 => 27,  120 => 23,  116 => 21,  113 => 19,  111 => 18,  107 => 17,  102 => 14,  93 => 13,  81 => 10,  78 => 9,  69 => 8,  57 => 5,  52 => 4,  43 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.menu.html.twig' %}

{% block stylesheets %}
  <link rel=\"stylesheet\" href=\"{{ asset('css/dropzone.css') }}\">
  <link rel=\"stylesheet\" href=\"{{ asset('css/styles.css') }}\">
{% endblock %}

{% block javascripts %}
  <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js\"></script>
  <script type=\"text/javascript\" src=\"{{ asset('js/dropzone.js') }}\"></script>
{% endblock %}

{% block body %}
  <div id=\"bg\">
    <div id=\"\" style=\"color:white;\">
      <h1>
        {% for contnom in nom %}
      {#   {{ id_doc }}#}
        |
      {#   {{ id_cat }}#}
        |

        {{ contnom }}
        |

      {#   {{ taille }}#}
        |
        {#  {{ data_enrg }}#}
        {% endfor %}
      </h1>
    </div>
    {# {{ path('ajax_snippet_image_send') }} #}
    <div class=\"dropzone my-dropzone\" id=\"form_snippet_image\" action=\"\">
      <script type=\"text/javascript\" src=\"{{ asset('js/dropzone.js') }}\"></script>
    </div>

    <div id=\"\" style=\"\">
      <ul >
        <li>
          <a style=\"color:white;text-decoration:none;\" href=\"{{ path('re_ssources') }}\">
            <i class=\"fa fa-fw fa-lg fa-tachometer\"></i>
            Retour sur /res simple. -> redirection vers ressources_error.html.twig (error car pas d'{id} selectionné [voir les routings de notre Bundle])
          </a>
        </li>
      </ul>
    </div>

  {% block log %}
  <div id=\"\" style=\"color:white;\">
    <h1>
      {% for content in nom %}
    {#   {{ id_doc }}#}
      |
    {#   {{ id_cat }}#}
      |

    {{ nom }}
      |

    {#   {{ taille }}#}
      |
      {#  {{ data_enrg }}#}
      {% endfor %}
    </h1>
  </div>

  {% endblock %}
  </div>
{% endblock %}
", "ENTSiteBundle:Membre:ressources.html.twig", "/opt/lampp/htdocs/3c0m/src/ENT/SiteBundle/Resources/views/Membre/ressources.html.twig");
    }
}
